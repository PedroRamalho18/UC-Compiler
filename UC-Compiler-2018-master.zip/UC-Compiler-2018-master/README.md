# **Compiladores**

- UC-Compiler
- Cadeira de Compiladores - 2018
- LEI UC 

Development of a compiler for the UC language, which is a subset of C language (Compiladores 2019)

## **Made by**
- Maria Inês Roseiro
- Diogo Santos Amores
